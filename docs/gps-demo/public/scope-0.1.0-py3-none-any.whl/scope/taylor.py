import logging
import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Optional, Sequence, Tuple

import numpy as np
from jaxtyping import Int, UInt
from scipy.spatial import ConvexHull

from plainll.tm import SynthesisProblem

from .data import CodeGeometry

VarTriple = Tuple[int, int, int]
"""Three distinct variable indices (1-based indexing)"""

VariableSlice = Sequence[int]
"""n distinct variable indices (1-based indexing)"""

Exps = UInt[np.ndarray, "Mnz d"]
Coeffs = Int[np.ndarray, " Mnz"]


@dataclass
class TaylorSeries:
    exps: Exps
    coeffs: Coeffs

    def __post_init__(self):
        assert self.exps.shape[0] == self.coeffs.shape[0]

    @property
    def num_vars(self):
        return self.exps.shape[-1]

    @property
    def num_terms(self):
        return self.coeffs.size

    def poly_ascii(self, var_names: Optional[Sequence[str]] = None):
        if var_names is None:
            if self.num_vars <= 3:
                var_names = ["x", "y", "z"][: self.num_vars]
        assert var_names is not None, "Variable names must be provided if num_vars > 3"
        return format_poly_ascii_math(self.exps, self.coeffs, var_names)

    def poly_latex(self, var_names: Optional[Sequence[str]] = None):
        if var_names is None:
            if self.num_vars <= 3:
                var_names = ["x", "y", "z"][: self.num_vars]
        assert var_names is not None, "Variable names must be provided if num_vars > 3"
        return format_poly_latex_math(self.exps, self.coeffs, var_names)

    def slice(self, var_slice: VariableSlice) -> "TaylorSeries":
        coeffs = zero_out_non_slice_coeffs(self, var_slice)
        non_zero = coeffs != 0
        slice_exps = self.exps[:, [i - 1 for i in var_slice]]
        return TaylorSeries(slice_exps[non_zero], coeffs[non_zero])


def zero_out_non_slice_coeffs(
    ts: TaylorSeries, var_slice: VariableSlice
) -> Int[np.ndarray, " Mnz"]:
    d = ts.exps.shape[1]
    comp_slice = [r - 1 for r in range(1, d + 1) if r not in var_slice]
    non_slice_exps = ts.exps[:, comp_slice]
    zeroed_out = (non_slice_exps != 0).any(axis=1)
    coeffs = np.copy(ts.coeffs)
    coeffs[zeroed_out] = 0
    return coeffs


def _minimal_support_masks(exps, k=None):
    """
    exps: (Mnz, d) nonnegative ints.
    Returns a set of bitmasks for distinct *non-empty* minimal supports.
    If k is given, drops supports with size > k.
    """
    S = np.unique(exps != 0, axis=0)  # unique supports (m, d) bool
    if S.size == 0:
        return set()
    pop = S.sum(axis=1)
    keep = pop > 0
    if k is not None:
        keep &= pop <= k
    S = S[keep]
    masks = set()
    for row in S:
        m = 0
        for j in np.flatnonzero(row):  # 0-based var index
            m |= 1 << j
        masks.add(m)
    return masks


def get_interesting_slices(ts: TaylorSeries, k: int):
    """
    Return all size-k slices (1-based, lex-sorted rows) such that
    ts.slice(slice) is a non-zero polynomial in k variables (all k variables present)

    In other words, the slices that can be *partitioned*
    into disjoint minimal non-empty slices (supports) of `ts`.
    """
    min_masks = _minimal_support_masks(ts.exps, k=k)
    if not min_masks:
        return np.empty((0, k), dtype=int)

    # DP over disjoint unions (only keep unions with size <= k)
    closure = {0}
    for m in min_masks:
        pm = m.bit_count()
        if pm > k:
            continue
        for u in list(closure):
            if (u & m) == 0 and (u.bit_count() + pm) <= k:
                closure.add(u | m)

    # Take exactly size-k unions and decode to 1-based tuples
    out = []
    for u in closure:
        if u.bit_count() == k:
            inds = []
            j, tmp = 0, u
            while tmp:
                if tmp & 1:
                    inds.append(j + 1)  # 1-based
                tmp >>= 1
                j += 1
            out.append(tuple(inds))

    out.sort()
    return [tuple(exp) for exp in out]


def get_non_trivial_slices(ts: TaylorSeries, k: int):
    """
    Return all slices s of size k such that ts.slice(s) is non-zero
    """
    out = []
    count_zeros = np.count_nonzero(ts.exps, axis=-1)
    exps = ts.exps[count_zeros <= k & ts.coeffs != 0]
    for exp in exps:
        s = np.flatnonzero(exp) + 1
        out.append(tuple(s))
    return list(sorted(set(out)))


def make_factorial_table(n: int) -> np.ndarray:
    # Maximum n such that n! fits in int32 is 12 (12! = 479,001,600 < 2^31-1)
    # 13! = 6,227,020,800 > 2^31-1
    if n > 12:
        raise ValueError(f"n={n} is too large; n! would overflow int32 (max n=12)")

    return np.concatenate(
        (
            np.array([1], dtype=np.int32),
            np.cumprod(np.arange(1, n + 1, dtype=np.int32)),
        ),
        dtype=np.int32,
    )


def reduced_taylor_series_from_code_geometry(
    code_geo: CodeGeometry, inf_prob: SynthesisProblem
) -> TaylorSeries:
    ders = code_geo.derivatives_vec.dot(inf_prob.counts)

    non_zero_rows = ders != 0
    non_zero_exps = code_geo.monomials[non_zero_rows]
    non_zero_ders = ders[non_zero_rows]

    logging.info(
        f"{non_zero_rows.shape[0]}/{code_geo.monomials.shape[0]} monomials have non-zero coeffs"
    )

    fact_table = make_factorial_table(code_geo.max_degree)
    k_factorial = fact_table[non_zero_exps].prod(axis=1)

    # Check divisibility before division
    if not (non_zero_ders % k_factorial == 0).all():
        mask = non_zero_ders % k_factorial != 0
        problem_ders = non_zero_ders[mask]
        problem_factorials = k_factorial[mask]
        problem_monomials = non_zero_exps[mask]
        raise ValueError(
            f"Derivative not divisible by factorial for variable slice {slice}. "
            f"Problem derivatives: {problem_ders}, "
            f"factorials: {problem_factorials}, "
            f"monomials: {problem_monomials}"
        )

    non_zero_coeffs = non_zero_ders // k_factorial

    return TaylorSeries(exps=non_zero_exps, coeffs=non_zero_coeffs)


def format_poly_ascii_math(
    exps: Exps,
    coeffs: Int[np.ndarray, " Mnz"],
    var_names: Sequence[str] = ("x", "y", "z"),
) -> str:
    assert len(var_names) == exps.shape[1]
    pieces = []
    for c, exp in zip(coeffs, exps):
        if c == 0:
            continue
        # sign
        sign = "+" if c > 0 else "-"
        # absolute value
        coeff = f"{abs(c)}"
        # 1 → do not print the coefficient unless the monomial is constant
        coeff = "" if coeff == "1" and exp.sum() != 0 else coeff
        # individual factors
        factors = []
        for n, var in zip(exp, var_names):
            if n == 0:
                continue
            factors.append(var if n == 1 else f"{var}^{n}")
        mon = "*".join(factors) if factors else "1"
        pieces.append(f"{sign} {coeff}{'*' if coeff and factors else ''}{mon}")
    # first sign is not needed if positive
    if pieces and pieces[0].startswith("+ "):
        pieces[0] = pieces[0][2:]

    # Join pieces and add line breaks when exceeding 80 characters
    result = " ".join(pieces)

    return result


def format_poly_latex_math(
    exps: Exps,
    coeffs: Int[np.ndarray, " Mnz"],
    var_names: Sequence[str] = ("x", "y", "z"),
) -> str:
    assert len(var_names) == exps.shape[1]
    pieces = []
    for c, exp in zip(coeffs, exps):
        if c == 0:
            continue
        # sign
        sign = "+" if c > 0 else "-"
        # absolute value
        coeff = f"{abs(c)}"
        # 1 → do not print the coefficient unless the monomial is constant
        coeff = "" if coeff == "1" and exp.sum() != 0 else coeff
        # individual factors
        factors = []
        for n, var in zip(exp, var_names):
            if n == 0:
                continue
            factors.append(var if n == 1 else f"{var}^{{{n}}}")
        mon = "".join(factors) if factors else "1"
        pieces.append(f"{sign} {coeff}{mon}")
    # first sign is not needed if positive
    if pieces and pieces[0].startswith("+ "):
        pieces[0] = pieces[0][2:]

    # Join pieces and add line breaks when exceeding 80 characters
    result = " ".join(pieces)

    return result


@dataclass(frozen=True, slots=True)
class NewtonDistanceResult:
    as_float: float  # finite value or math.inf
    as_fraction: Optional[Fraction]  # exact rational if finite
    is_exact: bool  # True ⇒ proven; False ⇒ upper bound
    explanation: Optional[str] = None  # None when distance is finite


def compute_newton_distance(
    exponents: Sequence[Sequence[int]],
    *,
    max_den: int = 1_000_000,
    variable_names: Optional[Sequence[str]] = None,
) -> NewtonDistanceResult:
    """
    Compute the Newton distance of a (truncated) polynomial.

    Parameters
    ----------
    exponents
        Iterable of length-d integer exponent vectors with non-zero derivatives.
    max_den
        Largest denominator when reconstructing Fraction values.
    variable_names
        Optional list like ['x','y','z'].  If shorter than the dimension,
        names continue as x4, x5, … .  Ignored extra names are dropped.

    Returns
    -------
    NewtonDistanceResult
    """
    # ------ normalise variable names -----------------------------------------
    K = np.asarray(exponents, dtype=float)
    if K.ndim != 2:
        raise ValueError("expecting an (N, d) array of exponents")
    N, d = K.shape
    if N == 0:
        raise ValueError("empty exponent list")

    if variable_names is None:
        variable_names = ["x", "y", "z"]
    names = list(variable_names) + [
        f"x{i + 1}" for i in range(len(variable_names or []), d)
    ]
    names = names[:d]  # truncate if too many were given

    # ------ identify constant vs varying axes --------------------------------
    spans = np.ptp(K, axis=0)  # per-axis (max – min)
    const_mask = spans == 0
    var_mask = ~const_mask

    # ---- conflicting constants  →  ∞ ---------------------------------------
    if const_mask.any():
        const_vals = K[0, const_mask]
        if not np.allclose(const_vals, const_vals[0], atol=0, rtol=0):
            vals_str = ", ".join(
                f"{n}={v:g}" for n, v in zip(np.array(names)[const_mask], const_vals)
            )
            return NewtonDistanceResult(
                as_float=math.inf,
                as_fraction=None,
                is_exact=True,
                explanation=(
                    "Some variables are frozen at different constants "
                    f"({vals_str}); the line x₁ = x₂ = cdots can’t pass through, "
                    "so the distance is infinite."
                ),
            )
        fixed_val = float(const_vals[0])
    else:
        fixed_val = None

    # ---- all axes constant  →  a single point -------------------------------
    if not var_mask.any():
        f = Fraction(int(round(fixed_val)), 1)  # type: ignore
        return NewtonDistanceResult(
            as_float=float(f),
            as_fraction=f,
            is_exact=True,
            explanation=None,
        )

    K_var = K[:, var_mask]

    # ---- diagonal vertex already present? -----------------------------------
    diag_rows = np.all(K_var == K_var[:, 0:1], axis=1)
    if diag_rows.any():
        s0 = float(K_var[diag_rows, 0].min())
        if fixed_val is None or math.isclose(s0, fixed_val):
            f = Fraction(int(round(s0)), 1)
            return NewtonDistanceResult(
                as_float=s0,
                as_fraction=f,
                is_exact=True,
                explanation=None,
            )
        diag_tuple = "(" + ", ".join(["s"] * len(names)) + ")"  # "(s,s,s,…)"
        return NewtonDistanceResult(
            as_float=math.inf,
            as_fraction=None,
            is_exact=True,
            explanation=(
                f"The diagonal point {diag_tuple} would meet the polyhedron when "
                f"s = {s0:g}, but the frozen variable(s) "
                f"{', '.join(np.array(names)[const_mask])} are fixed at {fixed_val:g}. "
                "Because those values differ, the diagonal cannot intersect the polyhedron, "
                "so the distance is infinite."
            ),
        )

    # ---- build convex hull in variable subspace -----------------------------
    try:
        hull = ConvexHull(K_var)
    except Exception as err:
        return NewtonDistanceResult(
            as_float=math.inf,
            as_fraction=None,
            is_exact=False,
            explanation=(
                "Convex-hull construction failed (Qhull error).  "
                "Likely all listed exponents lie in a lower-dimensional "
                "slice, making the intersection test impossible.  "
                f"Details: {err}"
            ),
        )

    best_frac: Optional[Fraction] = None
    best_float = math.inf
    active_deg = set()

    for eq, simplex in zip(hull.equations, hull.simplices):
        a, b = -eq[:-1], eq[-1]  # convert to A·x ≤ b with A ≥ 0
        if (a >= -1e-12).all():
            num = Fraction(b).limit_denominator(max_den)
            den = sum(Fraction(ai).limit_denominator(max_den) for ai in a)
            s = num / den
            if 0 < s < best_float:
                best_float = float(s)
                best_frac = s
                active_deg = {int(K[i].sum()) for i in simplex}

    # ---- no positive-orthant facet?  →  ∞ -----------------------------------
    if best_frac is None:
        return NewtonDistanceResult(
            as_float=math.inf,
            as_fraction=None,
            is_exact=True,
            explanation=(
                "Every face of the Newton polyhedron tilts away from the "
                "positive orthant, so the diagonal ray "
                "(x₁ = x₂ = cdots = s) never intersects it.  "
                "Hence the distance is infinite."
            ),
        )

    # ---- diagonal hits but clashes with fixed plane? ------------------------
    if fixed_val is not None and not math.isclose(best_float, fixed_val):
        return NewtonDistanceResult(
            as_float=math.inf,
            as_fraction=None,
            is_exact=True,
            explanation=(
                f"The diagonal would meet the polyhedron at s = {best_float:g}, "
                f"but the frozen variables "
                f"({', '.join(np.array(names)[const_mask])}) "
                f"are locked at {fixed_val:g}.  "
                "Because those values differ, no intersection is possible."
            ),
        )

    # ---- decide exact vs upper bound ---------------------------------------
    trunc_deg = int(K.sum(axis=1).max())
    is_exact = max(active_deg) < trunc_deg

    return NewtonDistanceResult(
        as_float=best_float,
        as_fraction=best_frac,
        is_exact=is_exact,
        explanation=None,
    )
