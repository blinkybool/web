from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import pyvista as pv


def make_isosurface_trace(points, values, isomin, isomax, count=1, **kwargs):
    return go.Isosurface(
        x=points[:, 0],
        y=points[:, 1],
        z=points[:, 2],
        value=values,
        isomin=isomin,
        isomax=isomax,
        surface=dict(count=count),
        caps=dict(x_show=False, y_show=False, z_show=False),
        **kwargs,
    )


def make_pyvista_mesh_trace(X, Y, Z, values, levels, **kwargs):
    X = np.asarray(X)
    Y = np.asarray(Y)
    Z = np.asarray(Z)
    values = np.asarray(values)
    grid = pv.StructuredGrid(X, Y, Z)

    grid.point_data["values"] = values.ravel(order="F")

    mesh = grid.contour(levels)

    # Use PyVista mesh
    verts = mesh.points
    faces = mesh.faces.reshape(-1, 4)[:, 1:4]  # PyVista format to triangle indices

    return go.Mesh3d(
        x=verts[:, 0],
        y=verts[:, 1],
        z=verts[:, 2],
        i=faces[:, 0],
        j=faces[:, 1],
        k=faces[:, 2],
        # color="#4A90E2",
        showscale=False,
        lighting=dict(ambient=0.5, diffuse=0.8, specular=0.1),
        lightposition=dict(x=100, y=200, z=0),
        showlegend=True,
        **kwargs,
    )
