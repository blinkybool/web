from typing import Tuple

import numpy as np
from jaxtyping import Float, UInt

from .taylor import Coeffs, Exps, TaylorSeries


def eval_poly(
    exps: UInt[np.ndarray, "Mnz v"],
    coeffs: Float[np.ndarray, " Mnz"],
    points: Float[np.ndarray, "*batch v"],
):
    # points: (..., v), exps: (Mnz, v)
    # we want summands to be (..., Mnz)
    points_reshaped = points[..., np.newaxis, :]  # (..., 1, v)
    exps_reshaped = exps[np.newaxis, ...]  # (1, Mnz, v)

    # power result is (..., Mnz, v)
    # prod result is (..., Mnz)
    summands = np.prod(np.power(points_reshaped, exps_reshaped), axis=-1)

    # dot product with coeffs (Mnz,) -> result is (...,)
    return np.dot(summands, coeffs)


def batch_eval_poly_3d(
    exps: UInt[np.ndarray, "Mnz 3"],
    coeffs: Float[np.ndarray, " Mnz"],
    X: Float[np.ndarray, " B"],
    Y: Float[np.ndarray, " B"],
    Z: Float[np.ndarray, " B"],
):
    points = np.stack([X.flatten(), Y.flatten(), Z.flatten()], axis=-1)
    return eval_poly(exps, coeffs, points)


def batch_eval_poly_2d(
    exps: UInt[np.ndarray, "Mnz 2"],
    coeffs: Float[np.ndarray, " Mnz"],
    X: Float[np.ndarray, " B"],
    Y: Float[np.ndarray, " B"],
):
    points = np.stack([X.flatten(), Y.flatten()], axis=-1)
    return eval_poly(exps, coeffs, points)


def _eval_on_grid_3d(
    exps: Exps,
    coeffs: Coeffs,
    *,
    resolution: int,
    bound: float = 1.0,
    power: int = 1,
) -> Tuple[
    Float[np.ndarray, " X"],
    Float[np.ndarray, " Y"],
    Float[np.ndarray, " Z"],
    Float[np.ndarray, " value"],
]:
    lin = np.linspace(-bound, bound, num=2**resolution, dtype=np.float64)
    nonlin = np.sign(lin) * np.power(np.abs(lin), power)
    X, Y, Z = np.meshgrid(nonlin, nonlin, nonlin, indexing="ij")
    values = batch_eval_poly_3d(exps, coeffs, X, Y, Z)
    values = values.reshape(X.shape)
    return X, Y, Z, values


def eval_on_grid_3d(
    ts: TaylorSeries, resolution: int, bound: float = 1.0, power: int = 1
) -> Tuple[
    Float[np.ndarray, " X"],
    Float[np.ndarray, " Y"],
    Float[np.ndarray, " Z"],
    Float[np.ndarray, " value"],
]:
    return _eval_on_grid_3d(
        ts.exps, ts.coeffs, resolution=resolution, bound=bound, power=power
    )


def eval_on_grid_2D(
    ts: TaylorSeries, resolution: int, bound: float = 1.0, power: int = 1
) -> Tuple[
    Float[np.ndarray, " W"],
    Float[np.ndarray, " H"],
    Float[np.ndarray, "H W"],
]:
    exps, coeffs = ts.exps, ts.coeffs
    lin = np.linspace(-bound, bound, num=2**resolution, dtype=np.float64)
    nonlin = np.sign(lin) * np.power(np.abs(lin), power)
    x, y = np.meshgrid(nonlin, nonlin, indexing="xy")
    x = x[None, :, :]
    y = y[None, :, :]
    n = exps[:, 0, None, None]
    m = exps[:, 1, None, None]
    coeffs = coeffs[:, None, None]
    terms = coeffs * np.power(x, n) * np.power(y, m)
    values = terms.sum(axis=0)
    return nonlin, nonlin, values
