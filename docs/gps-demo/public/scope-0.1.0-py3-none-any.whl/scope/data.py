from dataclasses import dataclass
from pathlib import Path

import numpy as np
from jaxtyping import Int32, UInt8


# Must be identical to syndra/geometry.py:CodeGeometry
# Except for importing as numpy arrays, not jax
@dataclass
class CodeGeometry:
    max_degree: int
    monomials: UInt8[np.ndarray, "M d"]
    error_counts: Int32[np.ndarray, "M I"]
    influences: Int32[np.ndarray, "M I"]
    derivatives_vec: Int32[np.ndarray, "M I"]

    def save(self, path: Path):
        """Save the CodeGeometry to a numpy archive file."""
        np.savez_compressed(
            path,
            max_degree=self.max_degree,
            monomials=self.monomials,
            error_counts=self.error_counts,
            influences=self.influences,
            derivatives_vec=self.derivatives_vec,
        )

    @classmethod
    def load(cls, path: Path):
        """Load a CodeGeometry from a numpy archive file."""
        data = np.load(path)
        return cls(
            max_degree=int(data["max_degree"]),
            monomials=data["monomials"],
            error_counts=data["error_counts"],
            influences=data["influences"],
            derivatives_vec=data["derivatives_vec"],
        )
