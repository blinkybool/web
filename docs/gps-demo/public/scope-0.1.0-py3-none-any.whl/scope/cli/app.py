from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from plainll.parse import parse_complete_tm
from scope.data import (
    CodeGeometry,
)
from scope.singular import (
    compute_resolution_data_from_taylor_series,
)
from scope.taylor import (
    get_interesting_slices,
    reduced_taylor_series_from_code_geometry,
)

app = typer.Typer(
    name="scope", no_args_is_help=True, pretty_exceptions_show_locals=False
)

console = Console()


@app.command()
def poly_ascii(
    x: Annotated[int, typer.Argument(help="X variable index (1-based)")],
    y: Annotated[int, typer.Argument(help="Y variable index (1-based)")],
    z: Annotated[int, typer.Argument(help="Z variable index (1-based)")],
    tm_path: Annotated[Path, typer.Option("--tm", help="Complete TM yaml file")],
    geo_path: Annotated[Path, typer.Option("--geo", help="Code Geometry npz file")],
):
    complete_tm = parse_complete_tm(tm_path)
    code_geo = CodeGeometry.load(geo_path)

    ts = reduced_taylor_series_from_code_geometry(
        code_geo, complete_tm.inference_problem
    )
    ts_slice = ts.slice((x, y, z))

    print(ts_slice.poly_ascii())


@app.command()
def lct(
    x: Annotated[int, typer.Argument(help="X variable index (1-based)")],
    y: Annotated[int, typer.Argument(help="Y variable index (1-based)")],
    z: Annotated[int, typer.Argument(help="Z variable index (1-based)")],
    tm_path: Annotated[Path, typer.Option("--tm", help="Complete TM yaml file")],
    geo_path: Annotated[Path, typer.Option("--geo", help="Code Geometry npz file")],
    timeout: Annotated[
        float, typer.Option("--timeout", help="Timeout in seconds")
    ] = 2.0,
):
    complete_tm = parse_complete_tm(tm_path)
    code_geo = CodeGeometry.load(geo_path)

    ts = reduced_taylor_series_from_code_geometry(
        code_geo, complete_tm.inference_problem
    )
    ts_slice = ts.slice((x, y, z))

    print(f"Polynomial: {ts_slice.poly_ascii()}")
    resolution = compute_resolution_data_from_taylor_series(ts_slice, timeout=timeout)
    if resolution:
        print("Minimum degree:", resolution.min_deg)
        print(
            "m_i / (k_i+1) = { "
            + ", ".join(
                f"{e.multiplicity}/{e.nu}" for e in resolution.exceptional_divisors
            )
            + " }"
        )
        lct = resolution.lct
        print(f"LCT: {lct} = {float(lct)}")
    else:
        print("LCT: unknown")


@app.command()
def triples(
    tm_path: Annotated[Path, typer.Option("--tm", help="Complete TM yaml file")],
    geo_path: Annotated[Path, typer.Option("--geo", help="Code Geometry npz file")],
):
    complete_tm = parse_complete_tm(tm_path)
    code_geo = CodeGeometry.load(geo_path)

    ts = reduced_taylor_series_from_code_geometry(
        code_geo, complete_tm.inference_problem
    )

    for exp, coeff in zip(ts.exps, ts.coeffs):
        print([int(n) for n in exp], int(coeff))

    # all_slices = [
    #     ((i, j, k), ts.slice((i, j, k)))
    #     for i, j, k in itertools.combinations(range(1, ts.exps.shape[1] + 1), 3)
    # ]
    # for (i, j, k), slice_ts in all_slices:
    #     if (slice_ts.coeffs != 0).any():
    #         print(slice_ts.coeffs)
    #         print((i, j, k), slice_ts.poly_ascii())

    # print(
    #     ts.poly_ascii(
    #         var_names=[f"w{i}" for i in range(1, ts.exps.shape[1] + 1)]
    #     )
    # )
    #
    triples = get_interesting_slices(ts, 3)

    for i, j, k in triples:
        print(f"{i}, {j}, {k}", ts.slice((i, j, k)).poly_ascii())


if __name__ == "__main__":
    triples(Path("tm/detectA0.yml"), Path("data/detectA0/exec_max_degree_5.npz"))
