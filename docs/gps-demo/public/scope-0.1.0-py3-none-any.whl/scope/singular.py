import logging
import subprocess
import textwrap
from dataclasses import dataclass
from fractions import Fraction
from typing import List, Optional

import sympy as sp

from .taylor import TaylorSeries, format_poly_ascii_math

x, y, z = sp.symbols("x y z")


def to_sg(e):
    return str(e.expand()).replace("**", "^")


def run_singular(script: str) -> str:
    return subprocess.check_output(
        ["Singular", "-q"], input=script.encode()
    ).decode()


@dataclass
class ExceptionalDivisor:
    multiplicity: int
    nu: int


@dataclass
class ResolutionData:
    exceptional_divisors: List[ExceptionalDivisor]
    min_deg: int

    @property
    def lct(self):
        if not self.exceptional_divisors:
            return Fraction(1, self.min_deg)
        return min(
            Fraction(e.multiplicity, e.nu)
            for e in self.exceptional_divisors
            if e.multiplicity > 0
        )


def compute_resolution_data_from_taylor_series(
    ts: TaylorSeries, timeout: Optional[float] = None
) -> Optional[ResolutionData]:
    if ts.num_vars == 2:
        var_names = ["x", "y"]
    elif ts.num_vars == 3:
        var_names = ["x", "y", "z"]
    else:
        raise ValueError(f"Unsupported number of variables {ts.num_vars}")
    poly = format_poly_ascii_math(ts.exps, ts.coeffs, var_names)
    return compute_resolution_data(poly, var_names, timeout)


def compute_resolution_data(
    poly: str,
    vars: List[str],
    timeout: Optional[float] = None,
    verbose: bool = False,
) -> Optional[ResolutionData]:
    # Check if singular command is available
    try:
        subprocess.check_output(
            ["command", "-v", "singular"], stderr=subprocess.DEVNULL
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        raise RuntimeError(
            "singular command not found. Please install singular computer algebra system (brew install singular)"
        )

    sing_script = textwrap.dedent(f"""
      LIB "resolve.lib";
      LIB "reszeta.lib";
      option(redSB);

      ring R = 0,({", ".join(vars)}),dp;
      ideal I = {poly};

      print("MINDEG " + string(mindeg(I)));

      list L  = resolve(I);
      list ex_divisors = prepEmbDiv(L,1); // exceptional divisors only
      int NUM = size(ex_divisors);

      if (NUM > 0) {{
        intvec N = computeN(L,ex_divisors);
        intvec NU = computeV(L,ex_divisors);
        int i;
        string s;
        for (i=1;i<=NUM;i++)
        {{
            print("DIV " + string(N[i]) + " " + string(NU[i]));
        }}
      }}
    """)

    try:
        result = subprocess.run(
            ["singular", "-q"],
            input=sing_script,
            text=True,
            capture_output=True,
            check=True,
            timeout=timeout,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        logging.warning("Failed compute resolution.")
        return None

    if verbose:
        print(result.stdout)

    ex_divisors: List[ExceptionalDivisor] = []
    min_deg: Optional[int] = None

    for line in result.stdout.splitlines():
        if line.startswith("MINDEG"):
            min_deg = int(line.split()[1])
        elif line.startswith("DIV"):
            mult, nu = map(int, line.split()[1:])
            ex_divisors.append(ExceptionalDivisor(mult, nu))
        elif verbose:
            logging.warning(line)

    if min_deg is None:
        logging.warning("Failed to compute minimum degree.")
        return None

    return ResolutionData(ex_divisors, min_deg)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: uv run singular.py 'polynomial'")
        sys.exit(1)

    poly = sys.argv[1]

    # Extract variable names from the polynomial
    variables_found = set()
    for var in ["x", "y", "z"]:
        if var in poly:
            variables_found.add(var)

    vars = sorted(list(variables_found))

    if not vars:
        print("No variables x, y, or z found in polynomial")
        sys.exit(1)

    timeout = None
    resolution = compute_resolution_data(poly, vars, timeout, verbose=True)
    print("Polynomial:", poly)
    if resolution:
        print("Minimum Degree:", resolution.min_deg)
        print(
            "m_i / (k_i+1) = { "
            + ", ".join(
                f"{e.multiplicity}/{e.nu}"
                for e in resolution.exceptional_divisors
            )
            + " }"
        )
        lct = resolution.lct
        print(f"LCT: {lct} = {float(lct)}")
    else:
        print("LCT: unknown")
