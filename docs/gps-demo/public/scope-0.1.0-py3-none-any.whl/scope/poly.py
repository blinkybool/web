import math
from typing import Optional, Sequence

import sympy as sp

from .taylor import TaylorSeries


def sympy_poly_from_taylor_series(
    ts: TaylorSeries, variables: Optional[Sequence[sp.Symbol]] = None
) -> sp.Poly:
    if variables is None:
        assert ts.num_vars <= 3, "Can't infer variable names for >3 variables"
        variables = sp.symbols("x,y,z")[:ts.num_vars]
    assert variables is not None
    poly = 0
    for coeff, exp in zip(ts.coeffs, ts.exps):
        poly += coeff * math.prod(
            var ** int(n) for var, n in zip(variables, exp) if n > 0
        )
    return sp.Poly(poly, domain="ZZ")
