import itertools
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    Iterable,
    List,
    Literal,
    Tuple,
    TypeVar,
    Union,
)

T = TypeVar("T")


@dataclass
class PlainFunc(Generic[T]):
    copies: List["Program[Any]"]
    func: Callable[..., T]
    name: str = "PF"


class Input(str):
    pass

    # def __repr__(self) -> str:
    #     return f"Input({super().__repr__()})"


Program = Union[PlainFunc[T], Input, T]
# For every variable, a count of the number occurrences of each value for that variable in an error syndrome
Weight = Tuple[Tuple[int, ...], ...]
SyndromeShape = Dict[Input, int]


class SyndromePath(tuple):
    def __str__(self):
        return "→".join(stringify_program_root(p) for p in self)


def stringify_program_root(program: Program) -> str:
    if isinstance(program, PlainFunc):
        return program.name
    elif isinstance(program, Input):
        return str(program)
    else:
        return str(program)


def stringify_program(
    program: Program,
    concrete: Literal["all", "simple", "omit"] = "all",
    precompute: bool = False,
    indices: bool = False,
):
    def rec(prog: Program):
        if isinstance(prog, PlainFunc):
            copy_strs = []
            for copy in prog.copies:
                if concrete == "all" or not is_concrete(copy):
                    copy_strs.append(rec(copy))
                else:
                    if concrete == "omit":
                        copy_strs.append("...")
                    elif concrete == "simple":
                        if isinstance(copy, PlainFunc):
                            copy_strs.append(copy.name + "(...)")
                        elif isinstance(copy, Input):
                            copy_strs.append(str(copy))
                        else:
                            copy_strs.append(repr(copy))
                    else:
                        raise NotImplementedError(f"Bad {concrete=}")

            if indices:
                copy_strs = [
                    f"{i}=={copy}" if copy != "..." else "..."
                    for i, copy in enumerate(copy_strs)
                ]
            copy_strs = [
                x
                for i, x in enumerate(copy_strs)
                if not (x == "..." and i > 0 and copy_strs[i - 1] == "...")
            ]

            return f"{prog.name}({','.join(copy_strs)})"

        elif isinstance(prog, Input):
            return repr(prog)
        else:
            return repr(prog)

    if precompute:
        program = precompute_program(program)
    out = rec(program)

    return out


def get_syndrome_shape(program: Program) -> SyndromeShape:
    return dict(Counter(get_leaf_inputs(program)))


def is_concrete(program: Program[Any]) -> bool:
    if isinstance(program, PlainFunc):
        return all(is_concrete(copy) for copy in program.copies)
    elif isinstance(program, Input):
        return False
    else:
        return True


def _iter_dfs_inputs(program: Program[Any]) -> Iterable[Input]:
    if isinstance(program, PlainFunc):
        return itertools.chain.from_iterable(
            _iter_dfs_inputs(copy) for copy in program.copies
        )
    elif isinstance(program, Input):
        return (program,)
    else:
        return ()


def get_leaf_inputs(value: Program[Any]) -> List[Input]:
    return list(_iter_dfs_inputs(value))


def get_syndrome_paths(program: Program) -> Dict[Input, List[SyndromePath]]:
    paths = defaultdict(list)
    path = [program]

    def rec(prog: Program):
        if isinstance(prog, PlainFunc):
            for copy in prog.copies:
                path.append(copy)
                rec(copy)
                path.pop()
        elif isinstance(prog, Input):
            paths[prog].append(SyndromePath(reversed(path)))

    rec(program)
    return dict(paths)


def precompute_program(program: Program[T]) -> Program[T]:
    if isinstance(program, PlainFunc):
        copies = [precompute_program(copy) for copy in program.copies]
        if all(
            not isinstance(copy, Input) and not isinstance(copy, PlainFunc)
            for copy in copies
        ):
            return program.func(*copies)
        else:
            return PlainFunc(copies=copies, func=program.func, name=program.name)
    else:
        return program


def get_pattern_counts(program: Program[T]) -> Counter[Input]:
    return Counter(get_leaf_inputs(program))


def stringify_vector(vector: Dict[Any, int], values: List[Any]):
    if not set(vector.keys()).issubset(set(values)):
        raise ValueError(
            f"Vector keys {vector.keys()} are not a subset of the provided values {values}"
        )

    return (
        "["
        + ", ".join(f"{vector.get(value, 0)}" for value in values)
        + "]·["
        + ", ".join(f"\033[36m{value}\033[0m" for value in values)
        + "]"
    )
