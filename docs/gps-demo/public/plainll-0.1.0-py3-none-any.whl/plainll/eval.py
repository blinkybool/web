from typing import Any, Counter, Dict, Tuple, TypeVar

import jax.numpy as jnp
from jaxtyping import Array, UInt8

from .core import Input, PlainFunc, Program, get_leaf_inputs, is_concrete

InputSyndromeJax = UInt8[Array, " L"]
SyndromeJax = Tuple[InputSyndromeJax, ...]


class Register:
    input_syndrome: UInt8[Array, " L"]
    values: UInt8[Array, " values"]
    ptr: int

    def __init__(
        self,
        input_syndrome: UInt8[Array, " L"],
        values: UInt8[Array, " values"],
    ) -> None:
        self.input_syndrome = input_syndrome
        self.values = values
        self.ptr = 0

    def read(self) -> Any:
        ptr = self.ptr
        self.ptr += 1
        value_index = self.input_syndrome[ptr]
        return self.values[value_index]

    def reset(self):
        self.ptr = 0


Memory = Dict[Input, Register | UInt8]


def make_values_array_with_correct_at_zero(
    correct_index: UInt8,
    all_values: UInt8[Array, " N"],
) -> UInt8[Array, " N"]:
    """
    Returns a copy of `all_values` in which

        • everything that was **to the left of `correct`** is shifted
          one position to the right;
        • `correct` itself is written at position 0.

    In other words
        v[0]   = all_values[correct]
        v[i+1] = all_values[i]               for 0 ≤ i < correct_index
        v[i]   = all_values[i]               for i > correct_index
    so that the relative order of the other elements is preserved.
    """

    N = all_values.shape[0]
    output_indices = jnp.arange(N)

    # For each output position, determine which input position it should get
    input_indices = jnp.where(
        output_indices == 0,
        correct_index,
        jnp.where(output_indices <= correct_index, output_indices - 1, output_indices),
    )

    return all_values[input_indices]


def eval_with_syndrome_jax(
    program: Program[UInt8],
    inputs: Tuple[Input, ...],
    correct_value_indices: Tuple[UInt8, ...],
    values_by_input: Tuple[UInt8[Array, " values"], ...],
    syndrome: SyndromeJax,
    debug=False,
    validate=False,
) -> UInt8:
    memory: Memory = {
        input: Register(
            input_syndrome,
            make_values_array_with_correct_at_zero(correct_index, values),
        )
        for input, input_syndrome, correct_index, values in zip(
            inputs, syndrome, correct_value_indices, values_by_input
        )
    }
    if validate:
        leaf_inputs = get_leaf_inputs(program)

        true_input_lengths = Counter(leaf_inputs)
        for input, input_syndrome in zip(inputs, syndrome):
            if input_syndrome.shape[0] != true_input_lengths[input]:
                raise ValueError(
                    f"Input syndrome at {input} has length {input_syndrome.shape[0]}, but should have length {true_input_lengths[input]}"
                )

    return run(program=program, memory=memory, debug=debug)


def eval_correct_jax(
    program: Program[UInt8],
    inputs: Tuple[Input, ...],
    values: Tuple[UInt8, ...],
    debug=False,
) -> UInt8:
    memory: Memory = {input: value for input, value in zip(inputs, values)}

    return run(program=program, memory=memory, debug=debug)


T = TypeVar("T")


def run(program: Program[T], memory: Memory, debug=False) -> T:
    if isinstance(program, PlainFunc):
        values = [
            run(program=copy, memory=memory, debug=debug) for copy in program.copies
        ]
        result = program.func(*values)
        if debug:
            print(
                f"{result} <- {program.name}("
                + ", ".join(
                    f"{copy.name if isinstance(copy, PlainFunc) else copy}:={value}"
                    for copy, value in zip(program.copies, values)
                    if not is_concrete(copy)
                )
                + ")"
            )
        return result
    elif isinstance(program, Input):
        reg_or_value = memory[program]
        if isinstance(reg_or_value, Register):
            return reg_or_value.read()
        else:
            return reg_or_value
    else:
        return program
