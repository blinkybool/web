from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml

from .tm import SynthesisProblem, TMModel, TransitionDict


@dataclass
class CompleteTM:
    """
    A complete Turing Machine specification including model, transitions,
    inference problem, and name.
    """

    model: TMModel
    delta: TransitionDict
    inference_problem: SynthesisProblem
    name: str

    def __post_init__(self):
        """Validate that all components are compatible after initialization."""
        self.model.validate_delta(self.delta)

    @property
    def code(self):
        """Get the TMCode from the delta."""
        return self.model.code_from_delta(self.delta)

    def __str__(self) -> str:
        """String representation of the CompleteTM."""
        return (
            f"CompleteTM({self.name}, "
            f"alphabet={self.model.alphabet}, "
            f"states={self.model.states}, "
            f"inputs={self.inference_problem.inputs})"
        )


def _load_yaml(content_or_path) -> dict:
    """Load YAML from string content or file path."""
    if isinstance(content_or_path, Path) or (
        isinstance(content_or_path, str) and Path(content_or_path).exists()
    ):
        with open(content_or_path, "r") as f:
            return yaml.safe_load(f.read())
    else:
        return yaml.safe_load(content_or_path)


def parse_tm_model(yaml_content_or_path) -> TMModel:
    """Parse a TMModel from YAML content or file path."""
    data = _load_yaml(yaml_content_or_path)

    alphabet = tuple(data["alphabet"])
    states = tuple(data["states"])
    initial_state = data["initial_state"]
    t = data["t"]

    # Generate all possible (alphabet, state) pairs
    descr_pairs = tuple((a, s) for a in alphabet for s in states)

    if initial_state not in states:
        raise ValueError(
            f"Initial state '{initial_state}' not found in states {states}"
        )

    return TMModel(
        alphabet=alphabet,
        states=states,
        descr_pairs=descr_pairs,
        initial_state=initial_state,
        t=t,
    )


def parse_transition_dict(yaml_content_or_path) -> TransitionDict:
    """Parse a TransitionDict from YAML content or file path."""
    data = _load_yaml(yaml_content_or_path)
    transitions_data = data["transitions"]

    transition_dict: TransitionDict = {}

    if not isinstance(transitions_data, list):
        raise ValueError("Transitions must be a list")

    for transition_data in transitions_data:
        if not isinstance(transition_data, list) or len(transition_data) != 5:
            raise ValueError(
                f"Invalid transition format: {transition_data}. Expected list of length 5: [read_symbol, current_state, write_symbol, next_state, direction]"
            )

        read_symbol, current_state, write_symbol, next_state, direction = (
            transition_data
        )

        if direction not in ["L", "S", "R"]:
            raise ValueError(
                f"Invalid direction '{direction}'. Must be 'L', 'S', or 'R'"
            )

        key = (read_symbol, current_state)

        if key in transition_dict:
            raise ValueError(
                f"Duplicate transition key {key}. Only one transition allowed per (read_symbol, current_state) pair"
            )

        value = (write_symbol, next_state, direction)
        transition_dict[key] = value

    return transition_dict


def parse_inference_problem(yaml_content_or_path) -> SynthesisProblem:
    """Parse an SynthesisProblem from YAML content or file path."""
    data = _load_yaml(yaml_content_or_path)

    if "inference_problem" not in data:
        raise ValueError("No 'inference_problem' key found in YAML")

    inf_data = data["inference_problem"]

    # Validate required fields
    for required_field in ["inputs", "outputs"]:
        if required_field not in inf_data:
            raise ValueError(f"No '{required_field}' key found in inference_problem")

    inputs = inf_data["inputs"]
    outputs = inf_data["outputs"]
    counts_spec = inf_data.get("counts", "uniform")

    if not isinstance(inputs, list):
        raise ValueError("'inputs' must be a list")

    if not isinstance(outputs, list):
        raise ValueError("'outputs' must be a list")

    if len(inputs) != len(outputs):
        raise ValueError(
            f"inputs length {len(inputs)} doesn't match outputs length {len(outputs)}"
        )

    # Parse counts
    if counts_spec == "uniform":
        counts = np.ones(len(inputs), dtype=np.int32)
    elif isinstance(counts_spec, list):
        if len(counts_spec) != len(inputs):
            raise ValueError(
                f"counts length {len(counts_spec)} doesn't match inputs length {len(inputs)}"
            )
        counts = np.array(counts_spec, dtype=np.int32)
    else:
        raise ValueError(
            f"Invalid counts format: {counts_spec}. Must be 'uniform' or a list of integers"
        )

    return SynthesisProblem(inputs=inputs, counts=counts, outputs=outputs)


def parse_complete_tm(yaml_content_or_path) -> CompleteTM:
    """Parse a CompleteTM from YAML content or file path."""
    data = _load_yaml(yaml_content_or_path)

    name = data["name"]

    # Parse components
    model = parse_tm_model(yaml_content_or_path)
    transition_dict = parse_transition_dict(yaml_content_or_path)
    inference_problem = parse_inference_problem(yaml_content_or_path)

    return CompleteTM(
        model=model,
        delta=transition_dict,
        inference_problem=inference_problem,
        name=name,
    )
