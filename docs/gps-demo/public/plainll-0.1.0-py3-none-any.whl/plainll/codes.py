import jax
import jax.numpy as jnp

from .tm import (
    DIRS,
    TM_DTYPE,
    SynthesisProblem,
    TMModel,
)
from .tm.program import TMCodeJax, eval_final_state_correct


def all_codes(model: TMModel):
    """
    Enumerate *every* TMCode for `model`.

    Returns
    -------
    writes, states, dirs : jnp.ndarray
        Each array has shape (N, D) with
        N = (|alphabet| * |states| * 3) ** D
        D = len(model.descr_pairs).

        Row i of the three matrices is the i-th code
        (in lexicographic order induced by the mesh-grid).
    """
    A = len(model.alphabet)  # |Σ|
    Q = len(model.states)  # |Q|
    T = len(model.descr_pairs)  # number of (read, state) pairs

    # 1. Build the lists that will be fed to meshgrid.
    #    For every square we need three axes: write-symbol, next-state, dir.
    grids = []
    for _ in range(T):
        grids.extend(
            [
                jnp.arange(A, dtype=TM_DTYPE),  # write choices
                jnp.arange(Q, dtype=TM_DTYPE),  # next-state choices
                jnp.arange(len(DIRS), dtype=TM_DTYPE),  # dir choices (0=L,1=S,2=R)
            ]
        )

    # 2. Full cartesian product with meshgrid.
    mg = jnp.meshgrid(*grids, indexing="ij")  # len(mg) == 3*T
    flat = [g.reshape(-1) for g in mg]  # each has shape (N,)

    # 3. Assemble the three (N, T) blocks.
    writes = jnp.stack(flat[0::3], axis=1)
    states = jnp.stack(flat[1::3], axis=1)
    dirs = jnp.stack(flat[2::3], axis=1)

    # Each of the three arrays is already UInt8 (TM_DTYPE).
    return writes, states, dirs


def compute_solution_codes(model: TMModel, synth_prob: SynthesisProblem):
    writes, states, dirs = all_codes(model)

    int_correct_outputs = jnp.array(
        [model.encode_state(state) for state in synth_prob.outputs], dtype=TM_DTYPE
    )
    int_tm_inputs = jnp.zeros((len(synth_prob.inputs), model.t + 1), dtype=TM_DTYPE)
    for i, tm_input in enumerate(synth_prob.inputs):
        for j, char in enumerate(tm_input):
            int_char = model.encode_symbol(char)
            int_tm_inputs = int_tm_inputs.at[i, j].set(int_char)

    def eval_one_code(code: TMCodeJax):
        matches_correct_output = jax.vmap(
            lambda x, y: eval_final_state_correct(model, code, x) == y
        )(int_tm_inputs, int_correct_outputs)

        all_correct = jnp.all(matches_correct_output)

        return all_correct

    solution_indices = jax.vmap(eval_one_code)((writes, states, dirs))
    solution_codes = (
        writes[solution_indices],
        states[solution_indices],
        dirs[solution_indices],
    )

    return solution_codes
