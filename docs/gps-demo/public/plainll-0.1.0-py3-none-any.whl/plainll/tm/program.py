from typing import Any, List, Tuple

import jax
import jax.numpy as jnp
from jaxtyping import Array, Int, UInt8

from plainll.core import PlainFunc, Program, SyndromeShape, get_syndrome_shape
from plainll.eval import SyndromeJax, eval_correct_jax, eval_with_syndrome_jax

from . import DIRS, TM_DTYPE, TMCode, TMConfig, TMModel

TMCodeJax = Tuple[UInt8[Array, " T"], UInt8[Array, " T"], UInt8[Array, " T"]]


def to_jax_code(code: TMCode) -> TMCodeJax:
    return (
        jnp.array(code[0], dtype=TM_DTYPE),
        jnp.array(code[1], dtype=TM_DTYPE),
        jnp.array(code[2], dtype=TM_DTYPE),
    )


def get_final_state_program(model: TMModel, tape: Array) -> Program:
    return make_sim_config(model, tape).state


def final_state_program_syndrome_shape(model: TMModel) -> SyndromeShape:
    tape = jnp.zeros(0, TM_DTYPE)
    program = get_final_state_program(model, tape)
    syndrome_shape = get_syndrome_shape(program)
    for transition in model.descr_triples:
        for square in transition:
            if square not in syndrome_shape:
                syndrome_shape[square] = 0
    return syndrome_shape


def get_descr_square_lengths(model: TMModel) -> Tuple[int, ...]:
    syndrome_shape = final_state_program_syndrome_shape(model)
    return tuple(syndrome_shape[square] for square in model.descr_squares)


def eval_final_state_with_syndrome(
    model: TMModel,
    code: TMCodeJax,
    int_tm_input: UInt8[Array, " chars"],
    syndrome: SyndromeJax,
):
    program = make_sim_config(model, int_tm_input)
    inputs = model.descr_squares

    correct_value_indices = []
    values_by_input = []
    int_alphabet = jnp.arange(len(model.alphabet), dtype=TM_DTYPE)
    int_states = jnp.arange(len(model.states), dtype=TM_DTYPE)
    int_dirs = jnp.arange(len(DIRS), dtype=TM_DTYPE)
    for w, qn, d in zip(*code):
        correct_value_indices.extend([w, qn, d])
        values_by_input.extend([int_alphabet, int_states, int_dirs])

    int_final_state = eval_with_syndrome_jax(
        program=program,
        inputs=inputs,
        correct_value_indices=tuple(correct_value_indices),
        values_by_input=tuple(values_by_input),
        syndrome=syndrome,
    )
    return int_final_state


def eval_final_state_correct(
    model: TMModel,
    code: TMCodeJax,
    int_tm_input: UInt8[Array, " chars"],
) -> UInt8:
    program = make_sim_config(model, int_tm_input).state
    inputs = model.descr_squares
    values = sum(((w, qn, d) for w, qn, d in zip(*code)), ())
    int_final_state = eval_correct_jax(
        program=program,
        inputs=inputs,
        values=values,
    )
    return int_final_state


NO_MATCH_VALUE = jnp.iinfo(TM_DTYPE).max
INT_DIRS = jnp.array([0, 1, 2], dtype=TM_DTYPE)
INT_LEFT, INT_STAY, INT_RIGHT = INT_DIRS
INT_BLANK = TM_DTYPE(0)
INT_INITIAL_STATE = TM_DTYPE(0)


def make_sim_config(
    model: TMModel,
    int_initial_tape: Int[Array, " I"],
) -> TMConfig:
    int_initial_tape = jnp.asarray(int_initial_tape, dtype=TM_DTYPE)

    descr_pairs = model.descr_pairs
    alphabet = model.alphabet
    states = model.states
    D = len(descr_pairs)
    assert len(alphabet) <= int(NO_MATCH_VALUE)
    assert len(states) <= int(NO_MATCH_VALUE)

    descr_reads = jnp.array(
        [alphabet.index(read) for read, _ in descr_pairs], dtype=TM_DTYPE
    )
    descr_states = jnp.array(
        [states.index(state) for _, state in descr_pairs],
        dtype=TM_DTYPE,
    )

    def compute_staging(
        read_vals: Tuple[Int, ...],
        state_vals: Tuple[Int, ...],
        output_vals: Tuple[Int, ...],
    ) -> Any:
        read_array = jnp.array(read_vals, dtype=TM_DTYPE)
        state_array = jnp.array(state_vals, dtype=TM_DTYPE)
        vals_array = jnp.array(output_vals, dtype=TM_DTYPE)
        matches = jnp.array(
            (read_array == descr_reads) & (state_array == descr_states),
            dtype=TM_DTYPE,
        )

        def scan_func(carry, x):
            match, value = x
            out = (1 - match) * carry + match * value
            # TODO: compare with jnp.where(match, value, carry)
            return out, None

        final_value, _ = jax.lax.scan(
            scan_func,
            NO_MATCH_VALUE,
            (matches, vals_array),
        )

        return final_value

    def rec(t: int, h: int) -> TMConfig:
        if t == 0:
            return TMConfig(
                left=[INT_BLANK] * h,
                head=int_initial_tape[0] if len(int_initial_tape) > 0 else INT_BLANK,
                right=[
                    int_initial_tape[i] if i < len(int_initial_tape) else INT_BLANK
                    for i in range(1, h + 1)
                ],
                state=INT_INITIAL_STATE,
            )

        prev = rec(t=t - 1, h=h + 1)

        stage_write = PlainFunc(
            [prev.head] * D + [prev.state] * D + list(model.write_squares),
            lambda *vals: compute_staging(
                read_vals=vals[:D],
                state_vals=vals[D : D * 2],
                output_vals=vals[D * 2 :],
            ),
            name="SW" + str(t),
        )

        stage_state = PlainFunc(
            [prev.head] * D + [prev.state] * D + list(model.state_squares),
            lambda *vals: compute_staging(
                read_vals=vals[:D],
                state_vals=vals[D : D * 2],
                output_vals=vals[D * 2 :],
            ),
            name="SQ" + str(t),
        )

        stage_dir = PlainFunc(
            [prev.head] * D + [prev.state] * D + list(model.dir_squares),
            lambda *vals: compute_staging(
                read_vals=vals[:D],
                state_vals=vals[D : D * 2],
                output_vals=vals[D * 2 :],
            ),
            name="SD" + str(t),
        )

        write = PlainFunc(
            [stage_write, prev.head],
            lambda s, h: jnp.where(s == NO_MATCH_VALUE, h, s),
            name="W" + str(t),
        )
        next_state = PlainFunc(
            [stage_state, prev.state],
            lambda s, q: jnp.where(s == NO_MATCH_VALUE, q, s),
            name="Q" + str(t),
        )
        move = PlainFunc(
            [stage_dir],
            lambda s: jnp.where(s == NO_MATCH_VALUE, INT_STAY, s),
            name="D" + str(t),
        )

        head = PlainFunc(
            [
                prev.left[0],
                prev.right[0],
                write,
                move,
            ],
            lambda a, b, w, m: jnp.array([a, w, b], dtype=TM_DTYPE)[m],
            name="H" + str(t),
        )

        left: List[Program[Int]] = []
        right: List[Program[Int]] = []

        if h > 0:
            left.append(
                PlainFunc(
                    [
                        prev.left[1],
                        prev.left[0],
                        write,
                        move,
                    ],
                    lambda a, b, w, m: jnp.array([a, w, b], dtype=TM_DTYPE)[m],
                )
            )
            right.append(
                PlainFunc(
                    [
                        prev.right[0],
                        prev.right[1],
                        write,
                        move,
                    ],
                    lambda a, b, w, m: jnp.array([w, a, b], dtype=TM_DTYPE)[m],
                )
            )

        for i in range(1, h):
            left.append(
                PlainFunc(
                    [
                        prev.left[i + 1],
                        prev.left[i],
                        prev.left[i - 1],
                        move,
                    ],
                    lambda a, b, g, m: jnp.array([a, g, b])[m],
                )
            )

            right.append(
                PlainFunc(
                    [
                        prev.right[i - 1],
                        prev.right[i],
                        prev.right[i + 1],
                        move,
                    ],
                    lambda a, b, g, m: jnp.array([a, g, b])[m],
                )
            )

        return TMConfig(
            left=left,
            right=right,
            head=head,
            state=next_state,
        )

    return rec(model.t, 0)
