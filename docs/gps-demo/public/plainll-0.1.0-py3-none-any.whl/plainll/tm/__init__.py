from dataclasses import dataclass
from functools import cached_property
from typing import Dict, Generic, List, Literal, Sequence, Tuple, TypeVar

import numpy as np
from jaxtyping import Int, UInt8

from plainll.core import (
    Input,
    Program,
)

Alph = str
State = str
Dir = Literal["L", "S", "R"]

LEFT = "L"
STAY = "S"
RIGHT = "R"
DIRS = [LEFT, STAY, RIGHT]


@dataclass(slots=True)
class SynthesisProblem:
    inputs: List[str]
    # Instead of a distribution q(x) we store integers c(x), with q(x) = c(x) / Σ_i c(i)
    counts: Int[np.ndarray, " inputs"]
    outputs: List[State]

    @classmethod
    def uniform(cls, inputs: List[str], outputs: List[State]):
        return cls(inputs, np.ones(len(inputs), dtype=np.int32), outputs)

    @property
    def dist(self):
        return self.counts.astype(np.float32) / self.counts.sum()


@dataclass
class TMConfig:
    left: List[Program[Int]]
    head: Program[Int]
    right: List[Program[Int]]
    state: Program[Int]


TM_DTYPE = np.uint8

TMDescription = Tuple[Tuple[Alph, State, Alph, State, Dir], ...]
NoisyTMDescription = Tuple[Tuple[TM_DTYPE, TM_DTYPE, Input, Input, Input], ...]

TransitionDict = Dict[Tuple[Alph, State], Tuple[Alph, State, Dir]]
TMCode = Tuple[
    UInt8[np.ndarray, " T"],
    UInt8[np.ndarray, " T"],
    UInt8[np.ndarray, " T"],
]


@dataclass
class TMCodeErrorSpec:
    write_errors: Sequence[Sequence[np.uint8]]
    state_errors: Sequence[Sequence[np.uint8]]
    dir_errors: Sequence[Sequence[np.uint8]]

    def validate(self, model: "TMModel", code: TMCode):
        writes, states, dirs = code
        assert len(model.descr_pairs) == len(self.write_errors)
        assert len(model.descr_pairs) == len(self.state_errors)
        assert len(model.descr_pairs) == len(self.dir_errors)

        assert all(
            all(0 <= e < len(model.alphabet) for e in errs)
            for errs in self.write_errors
        )
        assert all(
            all(0 <= e < len(model.states) for e in errs) for errs in self.state_errors
        )
        assert all(all(0 <= e < len(DIRS) for e in errs) for errs in self.dir_errors)

        assert all(
            all(e != c for e in errs) for c, errs in zip(writes, self.write_errors)
        )
        assert all(
            all(e != c for e in errs) for c, errs in zip(states, self.state_errors)
        )
        assert all(all(e != c for e in errs) for c, errs in zip(dirs, self.dir_errors))

        assert all(len(set(errs)) == len(errs) for errs in self.write_errors)
        assert all(len(set(errs)) == len(errs) for errs in self.state_errors)
        assert all(len(set(errs)) == len(errs) for errs in self.dir_errors)


T = TypeVar("T")


@dataclass
class TMVarInfo(Generic[T]):
    var_idx: int
    error: T


@dataclass
class TMSquareVarInfo(Generic[T]):
    correct: T
    errors: Sequence[TMVarInfo[T]]


@dataclass
class TMVarIdxInfo:
    correct: str
    error: str
    read: str
    state: str
    transition_idx: int
    output_idx: int

    @property
    def output_kind(self) -> Literal["write", "next_state", "dir"]:
        return ["write", "next_state", "dir"][self.output_idx]  # type: ignore


@dataclass
class TMCodeVarInfo:
    writes: Sequence[TMSquareVarInfo[Alph]]
    states: Sequence[TMSquareVarInfo[State]]
    dirs: Sequence[TMSquareVarInfo[Dir]]
    vars: Dict[int, TMVarIdxInfo]


@dataclass
class TMModel:
    alphabet: Tuple[Alph, ...]
    states: Tuple[State, ...]
    descr_pairs: Tuple[Tuple[Alph, State], ...]
    initial_state: State
    t: int

    @cached_property
    def write_squares(self) -> Tuple[Input, ...]:
        return tuple(Input(f"W{s}{q}") for s, q in self.descr_pairs)

    @cached_property
    def state_squares(self) -> Tuple[Input, ...]:
        return tuple(Input(f"Q{s}{q}") for s, q in self.descr_pairs)

    @cached_property
    def dir_squares(self) -> Tuple[Input, ...]:
        return tuple(Input(f"D{s}{q}") for s, q in self.descr_pairs)

    @cached_property
    def descr_triples(self) -> Tuple[Tuple[Input, Input, Input], ...]:
        return tuple(
            (w, q, d)
            for w, q, d in zip(self.write_squares, self.state_squares, self.dir_squares)
        )

    @cached_property
    def descr_squares(self) -> Tuple[Input, ...]:
        return sum(self.descr_triples, ())

    @cached_property
    def error_dims(self) -> Tuple[int, ...]:
        return sum(
            (
                (len(self.alphabet) - 1, len(self.states) - 1, len(DIRS) - 1)
                for _ in self.descr_triples
            ),
            (),
        )

    def validate_delta(self, delta: TransitionDict):
        if set(self.descr_pairs) != set(delta.keys()):
            missing = set(self.descr_pairs) - set(delta.keys())
            extra = set(delta.keys()) - set(self.descr_pairs)
            if missing:
                raise Exception(f"{missing} missing from transition dictionary")
            for s, q in extra:
                if s not in self.alphabet:
                    raise Exception(
                        f"Input-symbol {s} not found in alphabet {self.alphabet}"
                    )
                if q not in self.states:
                    raise Exception(
                        f"Input-state {q} not found in states {self.states}"
                    )
            if extra:
                raise Exception(
                    f"Input pairs {extra} not expected in transition dictionary"
                )
        for s, q, d in delta.values():
            if s not in self.alphabet:
                raise Exception(
                    f"Write-symbol {s} not found in alphabet {self.alphabet}"
                )

            if q not in self.states:
                raise Exception(f"Next-state {q} not found in states {self.states}")

            if d not in DIRS:
                raise Exception(f"Direction {s} not one of {DIRS}")

    def local_coordinates(self, code: TMCode):
        vars = []
        for (w, qn, d), (iw, iqn, id) in zip(zip(*code), self.descr_triples):
            for x in self.alphabet:
                if x != self.alphabet[w]:
                    vars.append((iw, self.alphabet[w], x))
            for x in self.states:
                if x != self.states[qn]:
                    vars.append((iqn, self.states[qn], x))
            for x in DIRS:
                if x != DIRS[d]:
                    vars.append((id, DIRS[d], x))
        return vars

    def full_canonical_error_spec(self, code: TMCode):
        writes, states, dirs = code
        write_errs = [
            [s for s in np.arange(0, len(self.alphabet), dtype=TM_DTYPE) if s != w]
            for w in writes
        ]
        state_errs = [
            [s for s in np.arange(0, len(self.states), dtype=TM_DTYPE) if s != qn]
            for qn in states
        ]
        dir_errs = [
            [s for s in np.arange(0, len(DIRS), dtype=TM_DTYPE) if s != d] for d in dirs
        ]
        return TMCodeErrorSpec(write_errs, state_errs, dir_errs)

    def get_code_var_info(self, code: TMCode, error_spec: TMCodeErrorSpec):
        write_infos = []
        state_infos = []
        dir_infos = []
        vars = {}

        var_idx = 1
        for i, (w, qn, d) in enumerate(zip(*code)):
            w_errs = error_spec.write_errors[i]
            qn_errs = error_spec.state_errors[i]
            d_errs = error_spec.dir_errors[i]

            s, q = self.descr_pairs[i]

            for j, (infos, values, correct, errs) in enumerate(
                [
                    (write_infos, self.alphabet, w, w_errs),
                    (state_infos, self.states, qn, qn_errs),
                    (dir_infos, DIRS, d, d_errs),
                ]
            ):
                var_infos = []
                for e in errs:
                    var_infos.append(
                        TMVarInfo(
                            var_idx=var_idx,
                            error=values[e],
                        )
                    )
                    vars[var_idx] = TMVarIdxInfo(
                        correct=values[correct],
                        error=values[e],
                        read=s,
                        state=q,
                        transition_idx=i,
                        output_idx=j,
                    )
                    var_idx += 1
                infos.append(TMSquareVarInfo(values[correct], var_infos))

        return TMCodeVarInfo(
            writes=write_infos,
            states=state_infos,
            dirs=dir_infos,
            vars=vars,
        )

    def encode_symbol(self, symbol: Alph) -> UInt8:
        return TM_DTYPE(self.alphabet.index(symbol))

    def encode_state(self, state: State) -> UInt8:
        return TM_DTYPE(self.states.index(state))

    def encode_dir(self, dir: Dir) -> UInt8:
        return TM_DTYPE(DIRS.index(dir))

    def code_from_delta(self, delta: TransitionDict) -> TMCode:
        self.validate_delta(delta)
        writes = []
        next_states = []
        dirs = []

        for s, q in self.descr_pairs:
            w, qn, d = delta[s, q]
            writes.append(self.encode_symbol(w))
            next_states.append(self.encode_state(qn))
            dirs.append(self.encode_dir(d))

        return (
            np.array(writes, dtype=TM_DTYPE),
            np.array(next_states, dtype=TM_DTYPE),
            np.array(dirs, dtype=TM_DTYPE),
        )
